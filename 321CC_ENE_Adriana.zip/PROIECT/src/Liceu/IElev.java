package Liceu;

import java.util.ArrayList;

public interface IElev {
	public String afisareDatePersonale(Elev e);
	public String afisareNote(SituatieMaterieBaza m);
	public String afisareMedie(SituatieMaterieBaza m);
	public String afisareAbsente(SituatieMaterieBaza m);
	
}
